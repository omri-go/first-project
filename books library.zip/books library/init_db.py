from app import db, app, Books, Customers, Loans

book1 = Books(name= "omri", author= "omriii", published_year= 1991, type= 1, image= "book1.jpg")
book2 = Books(name= "omri", author= "omr", published_year= 1961, type= 2, image= "book1.jpg")
book3 = Books(name= "omri", author= "irmo", published_year= 1901, type= 3, image= "book1.jpg")

customer1 = Customers(name= "omri", age= 30 , city= "Hadera")
customer2 = Customers(name= "omriii", age= 60 , city= "Had nes")
customer3 = Customers(name= "irmo", age= 90 , city= "Had ofan")

loans1 = Loans(customers_id= 1, book_id= 1)
loans2 = Loans(customers_id= 2, book_id= 2)
loans3 = Loans(customers_id= 3, book_id= 3)

with app.app_context():
    db.session.add_all([book1, book2, book3, customer1, customer2,customer3,loans1,loans2,loans3])
    db.session.commit()