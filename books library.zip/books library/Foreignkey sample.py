import json
from flask import Flask, request, flash, url_for, redirect, render_template
from flask_sqlalchemy import SQLAlchemy
 
app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///shop.sqlite3'
app.config['SECRET_KEY'] = "random string"
 
db = SQLAlchemy(app)
 
# model
class Category(db.Model):
    id = db.Column( db.Integer, primary_key = True)
    name = db.Column(db.String(100))
    category = db.relationship('Product', backref='category')
    def __init__(self, name):
        self.name = name
 
class Product(db.Model):
    id = db.Column( db.Integer, primary_key = True)
    name = db.Column(db.String(100))
    price = db.Column(db.Float())
   
    category_id = db.Column(db.Integer, db.ForeignKey('category.id'))
    def __init__(self, name, price,category=0):
        self.name = name
        self.price = price
        self.category_id = category
# model
 
# views
# category
@app.route('/newcat', methods = ['GET', 'POST'])
def new_cat():
    request_data = request.get_json()
    # print(request_data['city'])
    name= request_data["name"]
 
    newCategory= Category(name)
    db.session.add (newCategory)
    db.session.commit()
    return "a new category was create"
 
 
@app.route('/allcats', methods = ['GET', 'POST'])
def get_all_categories():
    res=[]
    for cat in Category.query.all():
        res.append({"name":cat.name,"id":cat.id})
    return  (json.dumps(res))
 
# product
@app.route('/newprod', methods = ['GET', 'POST'])
def new_prod():
    request_data = request.get_json()
    # print(request_data['city'])
    name= request_data["name"]
    price= request_data["price"]
    cat= request_data["cat"]
    print(price)
    newProduct= Product(name,price,cat)
    print(newProduct)
    db.session.add (newProduct)
    db.session.commit()
    return "a new product was create"
 
 
@app.route('/allprods', methods = ['GET', 'POST'])
def get_all_produtcs():
    res=[]
    for prod in Product.query.all():
        res.append({"name":prod.name,"id":prod.id})
    return  (json.dumps(res))
 
 
if __name__ == '__main__':
   db.create_all()
   app.run(debug = True)
