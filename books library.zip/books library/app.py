from flask import Flask, request,render_template
from flask_sqlalchemy import SQLAlchemy


app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///db_Books.sqlite3'
app.config['SECRET_KEY'] = "random string"

db = SQLAlchemy(app)


#################################
###########  MODELS  ############
#################################

######## model ########

class Customers(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), nullable=False)
    age = db.Column(db.Integer, nullable=False)
    city =  db.Column(db.String(50), nullable=False)
    loans = db.relationship('Loans', backref='customers', lazy=True)

    def __init__(self, name, age, city):
        self.name = name
        self.age = age
        self.city = city

######## model ########

class Loans(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    customers_id = db.Column(db.Integer, db.ForeignKey('customers.id'), nullable=False)
    book_id = db.Column(db.Integer, db.ForeignKey('books.id'), nullable=False)
    # loan_date = db.Column(db.Date, nullable=False)
    # return_date = db.Column(db.Date, nullable=False)

    def __init__(self, customers_id, book_id):#, loan_date, return_date):
        self.customers_id = customers_id
        self.book_id = book_id
        # self.loan_date = loan_date
        # self.return_date = return_date
        
######## model ########

class Books(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), nullable=False)
    author = db.Column(db.String(50), nullable=False)
    published_year = db.Column(db.Integer, nullable=False)
    type = db.Column(db.Integer, nullable=False)
    image = db.Column(db.String(50), nullable=False)
    loans = db.relationship('Loans', backref='books', lazy=True)

    def __init__(self, name, author, published_year, type, image):
        self.name = name
        self.author = author
        self.published_year = published_year
        self.type = type
        self.image = image


######## Home page  ########
@app.route("/")
def home():
    return  render_template('index.html') 


#################################
############  BOOKS  ############
#################################

######## show books data ########
@app.route("/books/<ind>")
@app.route("/books/")
def books_data(ind =-1):
    # one book
    if int(ind) > -1:
        book=Books.query.get(int(ind))
        return render_template('books.html',book=book) 
    # all books
    return render_template('books.html',books= Books.query.all()) 


######## add a book ########
@app.route("/add-book/", methods=['POST','GET'])
def add_book():
    request_data = request.get_json()
    name= request_data["name"]
    author= request_data["author"]
    published_year= request_data["published_year"]
    type= request_data["type"]
    image= ""
    if "image" not in request_data: #check if there is an image, if not, put default 
        image = "book-default.jpg"
    else:
        image= request_data["image"]
    newbook= Books(name, author, published_year, type, image)
    db.session.add (newbook)
    db.session.commit()
    return "a new book added"

######## delete a book ########
@app.route("/delete/<ind>", methods=['DELETE','GET'])
def delete_book(ind=-1):
        try: 
            print(ind)
            db.session.delete(Books.query.get(ind))
            db.session.commit()
        except:
            print("neyyyyy")
            return render_template('books.html',books= Books.query.all())
        print("what the .....")
        return render_template('books.html',books= Books.query.all())
        

######## update a book ########
@app.route("/update/<ind>", methods=['PUT'])
def update_book(ind=-1):
    if int(ind) > -1:
        data = request.json
        uname = (data["name"])
        book=Books.query.get(int(ind))
        if book:
            book.name=uname
            db.session.commit()
            return "book update"
        return "no such book to update"


###############################
#########  CUSTOMERS  #########
###############################

######## show Customers data ########
@app.route("/customers/<ind>")
@app.route("/customers/")
def customers_data(ind =-1):
    # one customer
    if int(ind) > -1:
        customer=Customers.query.get(int(ind))
        return render_template('customers.html',customer=customer) 
    # all customers
    return render_template('customers.html',customers= Customers.query.all())

######## add Customer ########
@app.route("/add-customer/", methods=['POST','GET'])
def add_customer():
    request_data = request.get_json()
    name= request_data["name"]
    age = request_data["age"]
    city = request_data["city"]

    newcustomer= Customers(name, age, city)
    db.session.add (newcustomer)
    db.session.commit()
    return "a new customer added"

######## delete Customer ########
@app.route("/delete/<ind>", methods=['DELETE','GET'])
def delete_customer(ind=-1):
        try: 
            print(ind)
            db.session.delete(Customers.query.get(ind))
            db.session.commit()
        except:
            return render_template('customers.html',customer= Customers.query.all())
        return render_template('customers.html',customer= Customers.query.all())


###############################
###########  LOANS  ###########
###############################

######## show Loans data ########
@app.route("/loans/<ind>")
@app.route("/loans/")
def loans_data(ind =-1):
    # one loan
    if int(ind) > -1:
        loan=Loans.query.get(int(ind))
        return render_template('loans.html',loan=loan) 
    # all loans
    return render_template('loans.html',loans= Loans.query.all())

######## add a loan ########
@app.route("/add_loan/", methods=['POST','GET'])
def add_loan():
    request_data = request.get_json()
    customers_id= request_data["customers_id"]
    book_id = request_data["book_id"]
    # loan_date = request_data["loan_date"]
    # return_date = request_data["return_date"]
    

    newloan= Loans(customers_id, book_id)#,loan_date, return_date)
    db.session.add (newloan)
    db.session.commit()
    return "a book was loaned"
    #return render_template("add_loan",)


if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)

